package com.example.livemeet.listeners;

import com.example.livemeet.models.User;

public interface UsersListener {

    void initiateVideoMeeting(User user);
    void initiateAudioMeeting(User user);

    void onMultipleUserAction(Boolean isMultipleUsersSelected);

}
